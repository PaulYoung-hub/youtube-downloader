const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { v4: uuidv4 } = require('uuid');

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const { url, type, quality } = JSON.parse(event.body);
    const downloadId = uuidv4();
    const tempDir = path.join(os.tmpdir(), downloadId);
    
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir);
    }

    const options = {
      format: type === 'audio' ? 'bestaudio[ext=m4a]' : `bestvideo[height<=${quality}][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best`,
      output: path.join(tempDir, '%(title)s.%(ext)s')
    };

    const command = `yt-dlp "${url}" ${
      type === 'audio' ? '--extract-audio --audio-format mp3' : ''
    } -f "${options.format}" -o "${options.output}"`;

    return new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          resolve({
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
          });
          return;
        }

        const files = fs.readdirSync(tempDir);
        const downloadedFile = files[0];
        const fileContent = fs.readFileSync(path.join(tempDir, downloadedFile));
        
        resolve({
          statusCode: 200,
          body: JSON.stringify({
            download_id: downloadId,
            filename: downloadedFile,
            content: fileContent.toString('base64')
          })
        });

        // Cleanup
        fs.rmSync(tempDir, { recursive: true, force: true });
      });
    });
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};
